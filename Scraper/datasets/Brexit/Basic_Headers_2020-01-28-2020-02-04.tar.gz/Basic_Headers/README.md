# Basic Headers:

All datasets in this directory named `scrape_data_XXXXX` contain Twitter Data in csv files labelled with the following headers in the following order:

`created_at`
`id`
`text`
`entities`
`source`
`user.id`
`user.screen_name`
`user.location`
`user.followers_count`
`user.friends_count`
`user.verified`
`user.statuses_count`
`geo`
`coordinates`
`place.name`
`user.location`
`retweet_count` 
`tweet.favorite_count` 
`tweet.favorited` 
`tweet.retweeted`
